function [ C1, C2 ] = Output_WT( H )

C1 = H;
C2 = zeros(1,8);

end

