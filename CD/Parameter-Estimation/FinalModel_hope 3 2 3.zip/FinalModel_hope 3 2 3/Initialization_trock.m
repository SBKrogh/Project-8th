function [ A, B1, C1, C2] = Initialization_trock 
%INITIALIZATION Summary of this function goes here
%   Detailed explanation goes here
matrices;
valve_param;
pipe_param;

zo = [1 2 1 2 3 2 1 2]' * 0.1;

[ lambdaD, lambdaC, pipe ] = Pipes( pipe, B_1, zo );
[ mu_S_D, mu_S_C, valve ] = Valves_States( valve, B_1, zo );
[ mu_I_D, mu_I_C, valve ] = Valves_Inputs( valve, B_1, zo);
[ gammaD, gammaC, pipe ] = Tower( pipe, B_1, zo );
[ C1, C2 ] = Output( lambdaC, mu_I_D, mu_S_C, B_1);
[ alpha_S ] = Pumps( B_1 );

WTconstant = (pi * 0.32^2 * 10^5)/(1000 * 9.8);

A =  (lambdaD + mu_S_D + gammaD);

B1 =  (-B_1 * mu_I_D + alpha_S);

end
