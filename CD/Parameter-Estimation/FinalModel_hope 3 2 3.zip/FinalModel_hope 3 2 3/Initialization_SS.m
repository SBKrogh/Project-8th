function [ A_c, B_c, C_c, D_c] = Initialization_SS( cosa ,Ts ) %#ok<INUSD>
%INITIALIZATION Summary of this function goes here
%   Detailed explanation goes here
matrices;
pipe_param;
valve_param;

% load('guess_A.mat');
load('M_N');


% load('est_trock_T.mat');

A = diag([linear_b_est(1) linear_b_est(2) linear_b_est(3) linear_b_est(4) linear_b_est(5) linear_b_est(6) linear_b_est(7)...
     linear_b_est(8) 0 linear_b_est(9) 0 0 linear_b_est(10) linear_b_est(11) linear_b_est(12) linear_b_est(13)...
     linear_b_est(14) 0 linear_b_est(15) linear_b_est(16) linear_b_est(17) linear_b_est(18) linear_b_est(19) linear_b_est(20)]);
% A = diag([a b c d e f g h 0 i 0 0 j k l m n 0 o p q r s t]);


M = B_1 * A * B_1';


% A = [ cosa(1)  cosa(2)    0   0   cosa(3)  0   0   0;
%     
%      cosa(2)  cosa(4)  cosa(5)  0   cosa(6)  cosa(7)  0   cosa(8);
%      
%      0       cosa(5)  cosa(9) cosa(10) 0 cosa(11) cosa(12) cosa(13);
%      
%      0      0       cosa(10) cosa(14) cosa(15) 0 cosa(16) cosa(17);
%      
%      cosa(3)  cosa(6)     0   cosa(15) cosa(18) 0       0         0;
%      
%      0      cosa(7)      cosa(11) 0       0   cosa(19) 0 cosa(20);
%      
%      0       0          cosa(12) cosa(16) 0   0   cosa(21) cosa(22);
%      
%      0      cosa(8)      cosa(13) cosa(17) 0 cosa(20) cosa(22) cosa(23)];
 
    
N = [ linear_b_est(21)   linear_b_est(22)   linear_b_est(23)   linear_b_est(24)   1   linear_b_est(25)   linear_b_est(26)   linear_b_est(27) ;
    linear_b_est(28)   linear_b_est(29)    linear_b_est(30)   linear_b_est(31)   linear_b_est(32)   linear_b_est(33)   1   linear_b_est(34);
    linear_b_est(35)   linear_b_est(36)    linear_b_est(37)    linear_b_est(38)   linear_b_est(39)   linear_b_est(40) -1 1;
    linear_b_est(41)   linear_b_est(42) linear_b_est(43)  linear_b_est(44)   linear_b_est(45)   1   linear_b_est(46)   1;
    linear_b_est(47)   linear_b_est(48)   linear_b_est(49)   linear_b_est(50)   linear_b_est(51)   1    linear_b_est(52)  linear_b_est(53) ;
    linear_b_est(54)    linear_b_est(55)    linear_b_est(56)   linear_b_est(57)   linear_b_est(58)   linear_b_est(59)   linear_b_est(60)   linear_b_est(61);
    linear_b_est(62)   linear_b_est(63)   linear_b_est(64) linear_b_est(65)   linear_b_est(66)   linear_b_est(67)   linear_b_est(68)   linear_b_est(69);
    linear_b_est(70) linear_b_est(71)  linear_b_est(72)    linear_b_est(73)   linear_b_est(74)   linear_b_est(75)   linear_b_est(76)   linear_b_est(77)];
    
C1 = [ cosa(1)  cosa(2) cosa(3) cosa(4) cosa(5) cosa(6) cosa(7) cosa(8);
    cosa(9)  cosa(10) cosa(11) cosa(12) cosa(13) cosa(14) cosa(15) cosa(16);
    cosa(17)  cosa(18) cosa(19) cosa(20) cosa(21) cosa(22) cosa(23) cosa(24);
    cosa(25)  cosa(26) cosa(27) cosa(28) cosa(29) cosa(30) cosa(31) cosa(32)];

C2 = [ cosa(33)  cosa(34) cosa(35) cosa(36) cosa(37) cosa(38) cosa(39) cosa(40);
    cosa(41)  cosa(42) cosa(43) cosa(44) cosa(45) cosa(46) cosa(47) cosa(48);
    cosa(49)  cosa(50) cosa(51) cosa(52) cosa(53) cosa(54) cosa(55) cosa(56);
    cosa(57)  cosa(58) cosa(59) cosa(60) cosa(61) cosa(62) cosa(63) cosa(64)];

% 
% 
% % C1 = [ zeros(1,5) cosa(46) 0    0;
% %     0 cosa(47) cosa(48) 0 0 cosa(49) 0 cosa(50);
% %     0 0 cosa(51) cosa(52) 0 0 cosa(53) cosa(54);
% %     0 0 0 0 0 0 cosa(55) 0 ];
% % 
% % C2 = [ cosa(56) zeros(1,7);
% %     0 cosa(57) zeros(1,6);
% %     0   0 cosa(58) zeros(1,5);
% %     0   0 0 cosa(59) zeros(1,4)];

WTconstant = (pipe.e26.area * 10^5)/(1000*9.8);
% 
% 
S =  (1/WTconstant) * pinv(H_0) * H_1 * B_1';

N_c = [ N(:,5) N(:,6)];

Q_c = [ N(:,2) N(:,4)];

C11 = [ C1(2,:); C1(4,:)];

C22 = [C2(2,2) C2(2,4);
    C2(4,2) C2(4,4)];


A_c =  S * (M \ B_0);

E_s = S * (M \ Q_c);

B_s = - S * (M \ N_c);

B_c = [B_s E_s];

D_s = [C11 * (M\N_c) ; zeros(1,2)];

C_c =  [- C11 * ( M \ B_0 ); 1];

K_s =  [C22 - C11 * ( M \ Q_c ); zeros(1,2)];

B_c = [B_s E_s];
D_c = [D_s K_s];

end
% 
% pipe.lambda(1) pipe.lambda(2) pipe.lambda(3) pipe.lambda(4) pipe.lambda(5)... 
%     pipe.lambda(6) pipe.lambda(7) pipe.lambda(8) pipe.lambda(10) pipe.lambda(13)...
%     pipe.lambda(14) pipe.lambda(16) pipe.lambda(19) pipe.lambda(20) pipe.lambda(21)...
%     valve.muI(15) valve.muI(17) valve.muI(22) valve.muI(23)...
%     valve.muS(15) valve.muS(17) valve.muS(22) valve.muS(23)

