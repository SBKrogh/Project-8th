%valve parameters



   valve.e02.Oo =  0;             %e2 - pipe
   valve.e04.Oo =  0;             %e4 - pipe
   valve.e05.Oo =  0;             %e5 - pipe
   valve.e06.Oo =  0;             %e6 - pipe
   valve.e11.Oo =  0;             %e11 - pipe
   valve.e21.Oo =  0;             %e21 - pipe
   valve.e23.Oo =  0;             %e23 - pipe
%----------------------------------------
   valve.e01.Oo =  0;               %e1 - Main pump 1
   valve.e03.Oo =  0;               %e3 - pipe
   valve.e07.Oo =  0;               %e7 - pipe
   valve.e08.Oo =  0;               %e8 - Main pump 2
   valve.e09.Oo =  0;               %e9 - PMA1 pump
   valve.e10.Oo =  0;               %e10 - pipe
   valve.e12.Oo =  0;               %e12 - pipe
   valve.e13.Oo =  0.7;             %e13 - Valve
   valve.e14.Oo =  0;               %e14 - pipe
   valve.e15.Oo =  0.7;             %e15 - Valve
   valve.e16.Oo =  0;               %e16 - PMA2 pump
   valve.e17.Oo =  0;               %e17 - pipe
   valve.e18.Oo =  0;               %e18 - pipe
   valve.e19.Oo =  0;               %e19 - pipe
   valve.e20.Oo =  0.7;             %e20 - Valve
   valve.e22.Oo =  0.7;             %e22 - Valve