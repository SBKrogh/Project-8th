% clear, clc
%% Initializing

[ A, B1, C1, C2] = Initialization_trock;


%% Load data from the lab
load('Long_data_new_layout.mat') % fits really great
Ts = 0.05;
u = u_sm;
y = y_sm;
% s = s_sm;
u(:,3:4) = 90 * u(:,3:4);
z = iddata(y,u,Ts,'Name', 'Data from Lab');
z.InputName = {'e01dp', 'e08dp', 'e15Cv', 'e22Cv'};
z.InputUnit =  {'bar', 'bar', '-','-',};
z.OutputName = {'PMA1', 'PMA2', 'WT'};
z.OutputUnit = {'bar', 'bar', 'bar'};

%% Set up the ident model 
a = A(1,1);
b = A(2,2);
c = A(3,3);
d = A(4,4);
e = A(5,5);
f = A(6,6);
g = A(7,7);
h = A(8,8);
i = A(10,10);
j = A(13,13);
k = A(14,14);
l = A(15,15);
m = A(16,16);
n = A(17,17);
o = A(19,19);
p = A(20,20);
q = A(21,21);
r = A(22,22);
s = A(23,23);
t = A(24,24);



% [B1(1,1); B1(1,2); B1(1,3); B1(1,4); B1(1,6); B1(1,7); B1(1,8);...
%         B1(2,1); B1(2,2); B1(2,3); B1(2,4); B1(2,5); B1(2,6);  B1(2,8);...
%         B1(3,1); B1(3,2); B1(3,3); B1(3,4); B1(3,5); B1(3,6);...
%         B1(4,1); B1(4,2); B1(4,3); B1(4,4); B1(4,5);  B1(4,7); ...
%         B1(5,1); B1(5,2); B1(5,3); B1(5,4); B1(5,5);  B1(5,7); B1(5,8);...
%         B1(6,1); B1(6,2); B1(6,3); B1(6,4); B1(6,5); B1(6,6); B1(6,7); B1(6,8);...
%         B1(7,1); B1(7,2); B1(7,3); B1(7,4); B1(7,5); B1(7,6); B1(7,7); B1(7,8);...
%         B1(8,1); B1(8,2); B1(8,3); B1(8,4); B1(8,5); B1(8,6); B1(8,7); B1(8,8)]};
cosa = { [C1(1,1); C1(1,2); C1(1,3); C1(1,4); C1(1,5); C1(1,6); C1(1,7); C1(1,8);...
C1(2,1); C1(2,2); C1(2,3); C1(2,4); C1(2,5); C1(2,6); C1(2,7); C1(2,8);...
C1(3,1); C1(3,2); C1(3,3); C1(3,4); C1(3,5); C1(3,6); C1(3,7); C1(3,8);...
C1(4,1); C1(4,2); C1(4,3); C1(4,4); C1(4,5); C1(4,6); C1(4,7); C1(4,8);...
C2(1,1); C2(1,2); C2(1,3); C2(1,4); C2(1,5); C2(1,6); C2(1,7); C2(1,8);...
C2(2,1); C2(2,2); C2(2,3); C2(2,4); C2(2,5); C2(2,6); C2(2,7); C2(2,8);...
C2(3,1); C2(3,2); C2(3,3); C2(3,4); C2(3,5); C2(3,6); C2(3,7); C2(3,8);...
C2(4,1); C2(4,2); C2(4,3); C2(4,4); C2(4,5); C2(4,6); C2(4,7); C2(4,8)]};
%                      
                     
Parameters =   {a ; b; c; d; e ; f; g; h; i ; j ; k; l ; m ; n; o; p; q; r; s; t};



linear_model = idgrey('Initialization_SS', [ cosa], 'c');

%  A(3,3); A(4,4); A(5,5); A(6,6); A(7,7); A(8,8);A(10,10);A(13,13); A(14,14); A(15,15); A(16,16); A(17,17); A(19,19); A(20,20); A(21,21); A(22,22); A(23,23); A(24,24);C2(4,5); C2(4,6); C2(4,7);B1(2,2);  B1(3,2); B1(3,3); B1(4,3); B1(6,1); B1(6,2); B1(7,3); B1(7,4);B1(8,2); B1(8,3);C1(1,1); C1(1,2); C1(1,3); C1(1,4); C1(1,5); C1(1,6); C1(1,7); C1(1,8);C1(2,1); C1(2,2); C1(2,3); C1(2,4); C1(2,5); C1(2,6); C1(2,7); C1(2,8);C1(3,1); C1(3,2); C1(3,3); C1(3,4); C1(3,5); C1(3,6); C1(3,7); C1(3,8);C1(4,1); C1(4,2); C1(4,3); C1(4,4); C1(4,5); C1(4,6); C1(4,7); C1(4,8);C2(1,1); C2(1,2); C2(1,3); C2(1,4); C2(1,5); C2(1,6); C2(1,7); C2(1,8);C2(2,1); C2(2,2); C2(2,3); C2(2,4); C2(2,5); C2(2,6); C2(2,7); C2(2,8);C2(3,1); C2(3,2); C2(3,3); C2(3,4); C2(3,5); C2(3,6); C2(3,7); C2(3,8);C2(4,1); C2(4,2); C2(4,3); C2(4,4); C2(4,8)
linear_model.Structure.Parameters(1).Minimum = 0;
linear_model.Structure.Parameters(2).Minimum = 0;
linear_model.Structure.Parameters(3).Minimum = 0;
linear_model.Structure.Parameters(4).Minimum = 0;
linear_model.Structure.Parameters(5).Minimum = 0;
linear_model.Structure.Parameters(6).Minimum = 0;
linear_model.Structure.Parameters(7).Minimum = 0;
linear_model.Structure.Parameters(8).Minimum = 0;
linear_model.Structure.Parameters(9).Minimum = 0;
linear_model.Structure.Parameters(10).Minimum = 0;
linear_model.Structure.Parameters(11).Minimum = 0;
linear_model.Structure.Parameters(12).Minimum = 0;
linear_model.Structure.Parameters(13).Minimum = 0;
linear_model.Structure.Parameters(14).Minimum = 0;
linear_model.Structure.Parameters(15).Minimum = 0;
linear_model.Structure.Parameters(16).Minimum = 0;
linear_model.Structure.Parameters(17).Minimum = 0;
linear_model.Structure.Parameters(18).Minimum = 0;
linear_model.Structure.Parameters(19).Minimum = 0;
linear_model.Structure.Parameters(20).Minimum = 0;



opt = greyestOptions('InitialState','zero','Display','on','SearchMethod', 'gn');
opt.SearchOption.MaxIter = 150;

datestr(now)
linear_estimation = greyest(z, linear_model, opt);
[linear_b_est,dlinear_b_est] = getpvec(linear_estimation,'free');
datestr(now)
figure